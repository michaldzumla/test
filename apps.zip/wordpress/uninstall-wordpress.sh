#!/bin/bash

docker rm db --force

docker rm wordpress --force

docker network rm wp